<?php
/**
 * Plugin Name: WooCommerce Carousel/Grid Marketplace & Pricing
 * Plugin URI: https://github.com/Jerel-R-Yoshida/wc-carousel-grid-marketplace-and-pricing
 * Description: Service marketplace with carousel/grid layout and tiered pricing (Entry/Mid/Expert) with monthly/hourly rates.
 * Version: 1.7.59
 * Author: Jerel Yoshida
 * Author URI: https://github.com/Jerel-r-yoshida
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wc-carousel-grid-marketplace-and-pricing
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 6.0
 * WC tested up to: 8.0
 */

defined('ABSPATH') || exit;

define('WC_CGMP_VERSION', '1.7.59');
define('WC_CGMP_PLUGIN_FILE', __FILE__);
define('WC_CGMP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WC_CGMP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WC_CGMP_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Only run stale path repair in admin context (not on every frontend page load)
if (is_admin() || (defined('WP_CLI') && WP_CLI)) {
    wc_cgmp_repair_stale_paths();
}

function wc_cgmp_repair_stale_paths(): void {
    $correct_path = 'wc-carousel-grid-marketplace-and-pricing/wc-carousel-grid-marketplace-and-pricing.php';
    $pattern = '#^wc-carousel-grid-marketplace-and-pricing(-[0-9.]+(-[a-z0-9]+)?)?/wc-carousel-grid-marketplace-and-pricing\.php$#i';
    
    $active_plugins = get_option('active_plugins', []);
    if (!is_array($active_plugins)) {
        return;
    }
    
    $has_stale = false;
    $has_correct = false;
    
    foreach ($active_plugins as $plugin) {
        if (preg_match($pattern, $plugin)) {
            if ($plugin === $correct_path) {
                $has_correct = true;
            } else {
                $has_stale = true;
            }
        }
    }
    
    if ($has_stale) {
        $active_plugins = array_filter($active_plugins, function($plugin) use ($pattern, $correct_path) {
            if (preg_match($pattern, $plugin)) {
                return $plugin === $correct_path;
            }
            return true;
        });
        
        if (!$has_correct) {
            $active_plugins[] = $correct_path;
        }
        
        update_option('active_plugins', array_values($active_plugins));
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[WC CGMP] Repaired stale plugin path references');
        }
    }
}
define('WC_CGMP_TABLE_TIERS', 'cgmp_product_tiers');
define('WC_CGMP_TABLE_SALES', 'cgmp_order_tier_sales');
define('WC_CGMP_DB_VERSION', '1.3.0');

define('WC_CGMP_META_LEARN_MORE_URL', '_wc_cgmp_learn_more_url');
define('WC_CGMP_META_APPLY_NOW_URL', '_wc_cgmp_apply_now_url');
define('WC_CGMP_META_ACTION_BUTTONS_ENABLED', '_wc_cgmp_action_buttons_enabled');

if (!function_exists('wc_cgmp_autoloader')) {
    function wc_cgmp_autoloader($class) {
        $prefix = 'WC_CGMP\\';
        $base_dir = WC_CGMP_PLUGIN_DIR . 'src/';

        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) !== 0) {
            return;
        }

        $relative_class = substr($class, $len);
        $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

        if (file_exists($file)) {
            require $file;
        }
    }

    spl_autoload_register('wc_cgmp_autoloader');
}

function wc_cgmp(): WC_CGMP\Core\Plugin {
    return WC_CGMP\Core\Plugin::get_instance();
}

function wc_cgmp_is_enabled(int $product_id): bool {
    return get_post_meta($product_id, '_wc_cgmp_enabled', true) === 'yes'
        || get_post_meta($product_id, '_welp_enabled', true) === 'yes';
}

function wc_cgmp_get_tiers(int $product_id): array {
    return wc_cgmp()->get_service('repository')->get_tiers_by_product($product_id);
}

function wc_cgmp_is_popular(int $product_id): bool {
    $method = get_option('wc_cgmp_popular_method', 'auto');

    if ($method === 'manual' || $method === 'both') {
        if (get_post_meta($product_id, '_wc_cgmp_popular', true) === 'yes') {
            return true;
        }
    }

    if ($method === 'auto' || $method === 'both') {
        $plugin = wc_cgmp();
        $repository = $plugin->get_service('repository');
        if ($repository) {
            return $repository->is_popular_auto($product_id);
        }
    }

    return false;
}

function wc_cgmp_get_learn_more_url(int $product_id): string {
    $url = get_post_meta($product_id, WC_CGMP_META_LEARN_MORE_URL, true);
    return $url ?: '';
}

function wc_cgmp_get_apply_now_url(int $product_id): string {
    $url = get_post_meta($product_id, WC_CGMP_META_APPLY_NOW_URL, true);
    return $url ?: '';
}

function wc_cgmp_get_button_urls(int $product_id): array {
    return [
        'learn_more' => wc_cgmp_get_learn_more_url($product_id),
        'apply_now' => wc_cgmp_get_apply_now_url($product_id),
    ];
}

function wc_cgmp_is_action_buttons_enabled(int $product_id): bool {
    $enabled = get_post_meta($product_id, WC_CGMP_META_ACTION_BUTTONS_ENABLED, true);
    if ($enabled === 'no') {
        return false;
    }
    return true;
}

function wc_cgmp_format_price(float $price, string $type = ''): string {
    $formatted = wc_price($price);

    if ($type === 'monthly') {
        return $formatted . '<span class="wc-cgmp-price-period">/mo</span>';
    } elseif ($type === 'hourly') {
        return $formatted . '<span class="wc-cgmp-price-period">/hr</span>';
    }

    return $formatted;
}

function wc_cgmp_log(string $message, array $context = []): void {
    if (defined('WP_DEBUG') && WP_DEBUG) {
        $logger = wc_cgmp()->get_service('logger');
        if ($logger) {
            $logger->debug($message, $context);
        }
    }
}

function wc_cgmp_logger(): ?\WC_CGMP\Core\Debug_Logger {
    return \WC_CGMP\Core\Debug_Logger::get_instance();
}

function wc_cgmp_get_help_icon(): string {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>';
}

function wc_cgmp_get_tier_icon(): string {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20V10"/><path d="M18 20V4"/><path d="M6 20v-4"/></svg>';
}

function wc_cgmp_get_entry_icon(): string {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/></svg>';
}

function wc_cgmp_get_mid_icon(): string {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
}

function wc_cgmp_get_expert_icon(): string {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m2 4 3 12h14l3-12-6 7-4-7-4 7-6-7zm3 16h14"/></svg>';
}

function wc_cgmp_get_settings_icon(): string {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>';
}

function wc_cgmp_get_chevron_icon(): string {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>';
}

function wc_cgmp_get_drag_icon(): string {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="5" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="9" cy="19" r="1"/><circle cx="15" cy="5" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="15" cy="19" r="1"/></svg>';
}

function wc_cgmp_get_check_icon(): string {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
}

function welp_is_enabled(int $product_id): bool {
    return wc_cgmp_is_enabled($product_id);
}

function welp_get_instance() {
    return wc_cgmp();
}

function welp_log() {
    return wc_cgmp()->get_service('logger');
}

function welp_debug(string $message, array $context = []): void {
    wc_cgmp_log($message, $context);
}

function welp_db_error(string $operation, string $error, array $context = []): void {
    if (defined('WP_DEBUG') && WP_DEBUG) {
        $logger = wc_cgmp()->get_service('logger');
        if ($logger) {
            $logger->db_error($operation, $error, $context);
        }
    }
}

function wc_cgm(): WC_CGMP\Core\Plugin {
    return wc_cgmp();
}

function wc_cgm_is_marketplace_product(int $product_id): bool {
    return wc_cgmp_is_enabled($product_id);
}

function wc_cgm_get_tiers(int $product_id): array {
    return wc_cgmp_get_tiers($product_id);
}

function wc_cgm_log(string $message, array $context = []): void {
    wc_cgmp_log($message, $context);
}

function wc_cgmp_check_elementor(): bool {
    return class_exists('\Elementor\Plugin') 
        || (did_action('elementor/loaded') && class_exists('\Elementor\Widget_Base'));
}

add_action('plugins_loaded', 'wc_cgmp_init', 11);

function wc_cgmp_init() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function() {
            echo '<div class="error"><p>';
            echo '<strong>WooCommerce Carousel/Grid Marketplace & Pricing</strong> requires WooCommerce to be installed and active.';
            echo '</p></div>';
        });
        return;
    }

    wc_cgmp();
}

add_action('plugins_loaded', 'wc_cgmp_init_category_icon_field', 15);

function wc_cgmp_init_category_icon_field(): void {
    new \WC_CGMP\Admin\Category_Icon_Field();
}

add_action('plugins_loaded', 'wc_cgmp_init_elementor', 5);

function wc_cgmp_init_elementor(): void {
    if (!did_action('elementor/loaded') && !class_exists('\Elementor\Plugin')) {
        return;
    }

    $file = WC_CGMP_PLUGIN_DIR . 'src/Elementor/Elementor_Integration.php';

    if (!file_exists($file)) {
        return;
    }

    require_once $file;
    \WC_CGMP\Elementor\Elementor_Integration::get_instance();
}

register_activation_hook(__FILE__, 'wc_cgmp_activate');

function wc_cgmp_activate(): void {
    if (!class_exists('WooCommerce')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(
            'WooCommerce Carousel/Grid Marketplace & Pricing requires WooCommerce to be installed and active.',
            'Plugin Activation Error',
            ['back_link' => true]
        );
    }

    require_once dirname(__FILE__) . '/src/Core/Activator.php';
    $activator = new WC_CGMP\Core\Activator();
    $activator->activate();
    
    wc_cgmp_repair_stale_paths();
}

register_deactivation_hook(__FILE__, 'wc_cgmp_deactivate');

function wc_cgmp_deactivate(): void {
    require_once dirname(__FILE__) . '/src/Core/Deactivator.php';
    $deactivator = new WC_CGMP\Core\Deactivator();
    $deactivator->deactivate();
}

add_action('admin_init', 'wc_cgmp_check_plugin_path_health');

function wc_cgmp_check_plugin_path_health(): void {
    if (!current_user_can('activate_plugins')) {
        return;
    }
    
    $correct_basename = plugin_basename(__FILE__);
    $active_plugins = get_option('active_plugins', []);
    $pattern = '#^wc-carousel-grid-marketplace-and-pricing(-[0-9.]+(-[a-z0-9]+)?)?/wc-carousel-grid-marketplace-and-pricing\.php$#i';
    
    foreach ($active_plugins as $plugin) {
        if (preg_match($pattern, $plugin) && $plugin !== $correct_basename) {
            add_action('admin_notices', function() use ($plugin, $correct_basename) {
                echo '<div class="notice notice-warning is-dismissible">';
                echo '<p><strong>WooCommerce Carousel/Grid Marketplace & Pricing:</strong> ';
                echo 'Detected stale plugin path reference. Please deactivate and reactivate the plugin to repair. ';
                echo '<br><code>Expected: ' . esc_html($correct_basename) . '</code>';
                echo '<br><code>Found: ' . esc_html($plugin) . '</code>';
                echo '</p></div>';
            });
            break;
        }
    }
}

add_action('plugins_loaded', 'wc_cgmp_init_sanitize_email_fix', 0);

function wc_cgmp_init_sanitize_email_fix(): void {
    if (get_option('wc_cgmp_fix_sanitize_email_null', true)) {
        add_filter('sanitize_email', 'wc_cgmp_sanitize_email_null_handler', 0, 3);
    }
}

function wc_cgmp_sanitize_email_null_handler($sanitized_email, $email, $context) {
    if ($email === null) {
        return '';
    }
    return $sanitized_email;
}

add_action('init', 'wc_cgmp_suppress_sanitize_email_deprecation', 0);

function wc_cgmp_suppress_sanitize_email_deprecation(): void {
    if (!get_option('wc_cgmp_fix_sanitize_email_null', true)) {
        return;
    }
    
    set_error_handler(function($errno, $errstr, $errfile, $errline) {
        if ($errno === E_DEPRECATED && strpos($errstr, 'strlen()') !== false && strpos($errfile, 'formatting.php') !== false) {
            return true;
        }
        return false;
    }, E_DEPRECATED);
}
