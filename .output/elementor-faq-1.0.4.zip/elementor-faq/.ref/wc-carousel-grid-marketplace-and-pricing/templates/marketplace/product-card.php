<?php
defined('ABSPATH') || exit;

$product = $product ?? null;
$product_id = $product ? $product->get_id() : 0;
$is_popular = $is_popular ?? false;
$specialization = $specialization ?? '';
$tiers = $tiers ?? [];
$atts = $atts ?? [];

$selected_tier = isset($atts['selected_tier']) ? (int) $atts['selected_tier'] : 0;
$tier_badges = [1 => 'Entry', 2 => 'Mid', 3 => 'Expert'];
$tier_classes = [1 => 'entry', 2 => 'mid', 3 => 'expert'];

$default_tier = null;

if ($selected_tier > 0) {
    foreach ($tiers as $tier) {
        if ((int) $tier->tier_level === $selected_tier && (($tier->hourly_price ?? 0) > 0 || ($tier->monthly_price ?? 0) > 0)) {
            $default_tier = $tier;
            break;
        }
    }
}

if (!$default_tier) {
    foreach ($tiers as $tier) {
        if (($tier->hourly_price ?? 0) > 0 || ($tier->monthly_price ?? 0) > 0) {
            $default_tier = $tier;
            break;
        }
    }
}

if (!$default_tier && !empty($tiers)) {
    $default_tier = $tiers[0];
}

$enable_modal = ($atts['enable_modal'] ?? 'true') === 'true';
$modal_description = get_post_meta($product_id, '_wc_cgmp_modal_description', true);
$key_responsibilities = get_post_meta($product_id, '_wc_cgmp_key_responsibilities', true);
$has_modal_content = !empty($modal_description) || (!empty($key_responsibilities) && is_array($key_responsibilities));
$show_modal_trigger = $enable_modal && $has_modal_content;
?>

<div class="wc-cgmp-card" data-product-id="<?php echo esc_attr($product_id); ?>" <?php echo !empty($tiers) ? 'data-has-tiers="true"' : ''; ?>>

    <?php 
    $show_popular_badge = ($atts['show_popular_badge'] ?? 'true') === 'true';
    $popular_badge_text_raw = $atts['popular_badge_text'] ?? 'Popular';
    $popular_badge_text = is_array($popular_badge_text_raw) ? ($popular_badge_text_raw['text'] ?? $popular_badge_text_raw[0] ?? 'Popular') : $popular_badge_text_raw;
    if ($is_popular && $show_popular_badge) : 
    ?>
    <span class="wc-cgmp-badge-popular">
        <?php echo esc_html($popular_badge_text); ?>
    </span>
    <?php endif; ?>

    <h3 class="wc-cgmp-card-title">
        <span class="wc-cgmp-title-text"><?php echo esc_html($product->get_name()); ?></span>
        <?php if ($show_modal_trigger) : ?>
        <span class="wc-cgmp-modal-trigger" data-product-id="<?php echo esc_attr($product_id); ?>" role="button" tabindex="0" aria-label="<?php esc_attr_e('View more details', 'wc-carousel-grid-marketplace-and-pricing'); ?>">
            <span class="wc-cgmp-question-icon">?</span>
        </span>
        <?php endif; ?>
        <?php
        $show_popular_mark = ($atts['show_popular_mark'] ?? 'false') === 'true';
        $popular_mark_text_raw = $atts['popular_mark_text'] ?? '‹popular›';
        $popular_mark_text = is_array($popular_mark_text_raw) ? ($popular_mark_text_raw['text'] ?? $popular_mark_text_raw[0] ?? '‹popular›') : $popular_mark_text_raw;
        if ($is_popular && $show_popular_mark) : ?>
        <span class="wc-cgmp-popular-mark"><?php echo esc_html($popular_mark_text); ?></span>
        <?php endif; ?>
        <?php
        $show_tier_badge = ($atts['show_tier_badge'] ?? 'true') === 'true';
        if ($show_tier_badge && !empty($tiers) && $default_tier && isset($tier_badges[$default_tier->tier_level])) : ?>
        <span class="wc-cgmp-tier-badge <?php echo esc_attr($tier_classes[$default_tier->tier_level] ?? 'default'); ?>">
            <?php echo esc_html($default_tier->tier_name ?: $tier_badges[$default_tier->tier_level]); ?>
        </span>
        <?php endif; ?>
    </h3>

    <?php
    $show_debug_popular = ($atts['show_debug_popular'] ?? 'false') === 'true';
    if ($show_debug_popular) : ?>
    <div class="wc-cgmp-debug-popular" style="font-size: 11px; color: #888; margin-bottom: 4px;">
        [DEBUG] Popular: <?php echo $is_popular ? 'true' : 'false'; ?> | Method: <?php echo esc_html(get_option('wc_cgmp_popular_method', 'auto')); ?> | Meta: <?php echo esc_html(get_post_meta($product_id, '_wc_cgmp_popular', true) ?: 'not set'); ?>
    </div>
    <?php endif; ?>

    <p class="wc-cgmp-card-desc">
        <?php
        $description = $product->get_description();
        if ($description) {
            echo esc_html(wp_trim_words($description, 30, '...'));
        } else {
            echo esc_html(wp_trim_words($product->get_short_description(), 30, '...'));
        }
        ?>
    </p>

    <?php echo \WC_CGMP\Frontend\Marketplace::render_pricing_panel($product, $tiers, $atts); ?>

    <?php if (wc_cgmp_is_action_buttons_enabled($product_id)) :
        $learn_more_url = wc_cgmp_get_learn_more_url($product_id);
        $apply_now_url = wc_cgmp_get_apply_now_url($product_id);

        if ($learn_more_url || $apply_now_url) : ?>
    <div class="wc-cgmp-action-buttons">
        <?php if ($learn_more_url) : ?>
            <a href="<?php echo esc_url($learn_more_url); ?>"
               class="wc-cgmp-button wc-cgmp-button-learn-more"
               target="_blank"
               rel="noopener noreferrer">
                <?php esc_html_e('Learn More', 'wc-carousel-grid-marketplace-and-pricing'); ?>
            </a>
        <?php endif; ?>

        <?php if ($apply_now_url) : ?>
            <a href="<?php echo esc_url($apply_now_url); ?>"
               class="wc-cgmp-button wc-cgmp-button-apply-now"
               target="_blank"
               rel="noopener noreferrer">
                <?php esc_html_e('Apply Now', 'wc-carousel-grid-marketplace-and-pricing'); ?>
            </a>
        <?php endif; ?>
    </div>
        <?php endif;
    endif; ?>
</div>
